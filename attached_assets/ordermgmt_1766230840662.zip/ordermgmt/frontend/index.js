var app = angular.module("myApp",[]);

app.controller("showOrders",function($scope,$http){
    //get order
    $http.post("http://127.0.0.1:8000/order/arrange",{page:1,pageSize:10})
    .then(function(response){
        $scope.orders = response.data.orders
    })
    .catch(function(error){
        console.error(error)
    })
    $http.get('http://127.0.0.1:8000/order/getOrders')
        .then(function(response){
            // $scope.orders = response.data.orders
            $scope.pages = response.data.totalPages
            $scope.pagesarray = []
            for (let i = 1;i<=$scope.pages;i++){
                $scope.pagesarray.push(i);
            }

        })
    //filter toggle
    $scope.showFilter = false;
    //delete
    $scope.showdelete = false;
    $scope.deleteOrder = function(pk){
        $http.delete('http://127.0.0.1:8000/order/deleteOrder/'+pk)
        .then(function(response){
            console.log("Success: ",response.data)
            // Refresh the customer list after deletion
            $scope.orders = $scope.orders.filter(c => c.orderId !== pk);
        })
        .catch(function (error) {
            // alert("Error deleting order.");
            console.error(error);
        });
    }
    //add
    $scope.showadd = false;
    $scope.addOrder = function(){
        var orderData = {
            customerId : $scope.newOrder.customerId,
            productId : $scope.newOrder.productId,
            quantity : $scope.newOrder.quantity,
            rate : $scope.newOrder.rate,
            orderStatus : $scope.newOrder.orderStatus
        }
        $http.post("http://127.0.0.1:8000/order/addOrder",orderData)
        .then(function(response){
            console.log("Success: ",response.data)
            // Add new customer to the table without reloading the page
            $scope.orders.push(response.data);
            // Clear form fields after submission
            $scope.newOrder = {};
            $scope.showadd = false;
        })
        .catch(function (error) {
            console.error(error);
        });
    }
    //edit
    $scope.showedit = false;
    $scope.edit = false;
    $scope.editOrder = function(order){
        $scope.order = angular.copy(order)
    }
    $scope.updateOrder = function(order){
        var updateData = {
            customerId : order.customerId,
            productId : order.productId,
            quantity : order.quantity,
            rate : order.rate,
            orderStatus : order.orderStatus
        }
        $http.put("http://127.0.0.1:8000/order/editOrder/"+order.orderId,updateData)
        .then(function(response){
            console.log(response.data)
        })
        .catch(function (error) {
            console.error(error);
        });
    }

    //get customers
    $http.get("http://127.0.0.1:8000/customer/getCustomers")
    .then(function(response){
        $scope.customers = response.data
    })
    //get products
    $http.get("http://127.0.0.1:8000/product/getProducts")
    .then(function(response){
        $scope.products = response.data
    })

    
    //filter default
    $scope.filter = {
        customerId: "all",
        productId : "all",
        fromDate : null,
        toDate : null,
    }
    //sort arrows
    $scope.downarrow = {};
    $scope.uparrow = {};
    const columns = ['orderId', 'customerId', 'productId', 'quantity', 'rate', 'orderDate', 'orderStatus'];
    columns.forEach(column => {
        $scope.downarrow[column] = false; // Default: Down arrow visible
        $scope.uparrow[column] = true;  // Default: Up arrow hidden
    });
    //column as default
    $scope.currentColumn = 'orderId'
    //arrange
    $scope.arrangeOrder = function(column,page,recPerPage,isSortClick){
        if (isSortClick){
        $scope.downarrow[column] = !$scope.downarrow[column];
        $scope.uparrow[column] = !$scope.downarrow[column];
        }
        if ($scope.downarrow[column]){
            $scope.columnName = "-"+column
        }
        else{
            $scope.columnName = column
        }
        var arrangeData = {
            page : page || 1,
            pageSize : recPerPage || 10,
            customerId : $scope.filter.customerId,
            productId : $scope.filter.productId,
            fromDate : $scope.filter.fromDate ? $scope.filter.fromDate : "all",
            toDate : $scope.filter.toDate ? $scope.filter.toDate : "all",
            column : $scope.columnName || "orderId"
        }
        $http.post("http://127.0.0.1:8000/order/arrange",arrangeData)
        .then(function(response){
            $scope.orders = response.data.orders
            $scope.pages = response.data.totalPages
            $scope.pagesarray = []
            for (let i = 1;i<=$scope.pages;i++){
                $scope.pagesarray.push(i);
            }
        })
        .catch(function(error){
            console.error(error)
        })
    }
})
