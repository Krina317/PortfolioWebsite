from django.db import models

class Products(models.Model):
    productId = models.CharField(max_length=10,primary_key=True)
    productCompany = models.CharField(max_length=100)
    productName = models.CharField(max_length=500)
    productStock = models.IntegerField()
    productType = models.CharField(max_length=100)
    productColor = models.CharField(max_length=100)
    productPrice = models.DecimalField(max_digits=9,decimal_places=2)
    productSupplier = models.CharField(max_length=100)
    reorderLevel = models.IntegerField()