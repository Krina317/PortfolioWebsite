from .views import getProducts
from django.urls import path

urlpatterns = [
    path('getProducts',getProducts,name='getProducts')
]
