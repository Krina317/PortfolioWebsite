from .views import getOrders,addOrder,editOrder,deleteOrder,arrange
from django.urls import path

urlpatterns = [
    path('getOrders',getOrders,name='getOrders'),
    path('addOrder',addOrder,name='addOrder'),
    path('editOrder/<int:pk>',editOrder,name='editOrder'),
    path('deleteOrder/<int:pk>',deleteOrder,name='deleteOrder'),
    path('arrange',arrange,name='arrange')
]
