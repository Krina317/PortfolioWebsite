from django.db import models

class Order(models.Model):
    orderId  = models.AutoField(primary_key=True)
    customerId = models.CharField(max_length=10)
    productId = models.CharField(max_length=10)
    quantity = models.IntegerField()
    rate = models.DecimalField(max_digits=9,decimal_places=2)
    orderDate = models.DateTimeField(auto_now_add=True)
    orderStatus = models.CharField(max_length=20)
    