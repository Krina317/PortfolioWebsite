from .serializers import OrderSerializer
from .models import Order
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from datetime import datetime, timedelta

# get orders and pages if pageSize = 10 for keeping 1 default page
@api_view(['GET'])
def getOrders(request):
    orders = Order.objects.all()
    serializer = OrderSerializer(orders,many=True)
    totalCount = Order.objects.count()
    pageSize = 10
    totalPages = (totalCount  + int(pageSize) -1) // int(pageSize)
    return Response({"orders":serializer.data,"totalPages":totalPages})

#add Order
@api_view(['POST'])
def addOrder(request):
    serialzer = OrderSerializer(data = request.data)
    if serialzer.is_valid():
        serialzer.save()
        return Response(serialzer.data,status=status.HTTP_201_CREATED)
    return Response(serialzer.errors,status=status.HTTP_400_BAD_REQUEST)

#edit Order
@api_view(['PUT'])
def editOrder(request,pk):
    order = Order.objects.get(pk=pk)
    serializer = OrderSerializer(order,data = request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data,status=status.HTTP_200_OK)
    return Response(serializer.error,status=status.HTTP_400_BAD_REQUEST)

#delete order
@api_view(['DELETE'])
def deleteOrder(request,pk):
    order = Order.objects.get(pk=pk)
    order.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)

#.filter.sort[start:end]
#in one api 


@api_view(['POST'])
def arrange(request):
    column = request.data.get('column',"orderId")
    pageNum = int(request.data.get('page',1))
    pageSize = int(request.data.get('pageSize',10))
    customerId = request.data.get('customerId',"all")
    productId = request.data.get('productId',"all")
    fromDate = request.data.get('fromDate',"all")
    toDate = request.data.get('toDate',"all")
    start = (pageNum-1)*pageSize
    end = start + pageSize
    filters = {}
    # Add customer and product filters if not "all"
    if customerId != "all":
        filters["customerId"] = customerId
    if productId != "all":
        filters["productId"] = productId
    if fromDate != "all" and toDate != "all":
        from_date = datetime.strptime(fromDate,'%Y-%m-%d')
        to_date = datetime.strptime(toDate,'%Y-%m-%d')+timedelta(days=1)-timedelta(microseconds=1)
        filters["orderDate__range"] = [from_date,to_date]
    try:
        order = Order.objects.filter(**filters).order_by(column)
        totalCount = order.count()
        totalPages = (totalCount  + int(pageSize) -1) // int(pageSize)
        paginatedOrder = order[start:end]
        serializer = OrderSerializer(paginatedOrder,many=True)
        return Response({"orders":serializer.data,"totalPages":totalPages},status=status.HTTP_200_OK)
    except Order.DoesNotExist:
        return Response({"orders":serializer.data,"totalPages":totalPages},status=status.HTTP_404_NOT_FOUND)


@api_view(['POST'])
def arrange(request):
    column = request.data.get('column',"orderId")
    pageNum = int(request.data.get('page',1))
    pageSize = int(request.data.get('pageSize',10))
    customerId = request.data.get('customerId',"all")
    print(customerId,pageNum,pageSize)
    productId = request.data.get('productId',"all")
    fromDate = request.data.get('fromDate',"all")
    toDate = request.data.get('toDate',"all")
    start = (pageNum-1)*pageSize
    end = start + pageSize
    filters = {}
    # Add customer and product filters if not "all"
    if customerId != "all":
        filters["customerId"] = customerId
    if productId != "all":
        filters["productId"] = productId
    if fromDate != "all" and toDate != "all":
        fd = fromDate[:fromDate.index('T')-2]
        td = toDate[:toDate.index('T')-2]
        dayfrom = str(fromDate[fromDate.index('T')-2] + fromDate[fromDate.index('T')-1])
        dayto = str(toDate[toDate.index('T')-2] + toDate[toDate.index('T')-1])
        if dayfrom == "31":
            dayfrom = "01"
        else: 
            dayfrom = int(dayfrom) + 1
        if dayto == "31":
            dayto = "01"
        else:
            dayto = int(dayto) + 1
        fd += str(dayfrom)
        td += str(dayto)
        from_date = datetime.strptime(fd,'%Y-%m-%d')
        to_date = datetime.strptime(td,'%Y-%m-%d')+timedelta(days=1)-timedelta(microseconds=1)
        filters["orderDate__range"] = [from_date,to_date]
    try:
        order = Order.objects.filter(**filters).order_by(column)
        totalCount = order.count()
        totalPages = (totalCount  + int(pageSize) -1) // int(pageSize)
        print(totalPages)
        paginatedOrder = order[start:end]
        serializer = OrderSerializer(paginatedOrder,many=True)
        return Response({"orders":serializer.data,"totalPages":totalPages},status=status.HTTP_200_OK)
    except Order.DoesNotExist:
        return Response({"orders":serializer.data,"totalPages":totalPages},status=status.HTTP_404_NOT_FOUND)