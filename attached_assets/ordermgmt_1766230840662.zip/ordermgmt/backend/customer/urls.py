from .views import getCustomers
from django.urls import path

urlpatterns = [
    path("getCustomers",getCustomers,name='getCustomers')
]
