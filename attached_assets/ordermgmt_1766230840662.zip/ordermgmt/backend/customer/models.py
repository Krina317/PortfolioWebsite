from django.db import models

class Customer(models.Model):
    customerId = models.CharField(max_length=10,primary_key=True)
    customerName = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)
    
